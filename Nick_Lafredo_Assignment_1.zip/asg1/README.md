Sources:
Claude for assistance
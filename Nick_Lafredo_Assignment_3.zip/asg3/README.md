Sources:
Claude